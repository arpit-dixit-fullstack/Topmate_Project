"use client"

import { motion } from "framer-motion"
import { Calendar, MessageSquare, Video, Star, Shield, Zap } from "lucide-react"

const features = [
  {
    icon: Calendar,
    title: "1:1 Sessions",
    description: "Book personalized one-on-one sessions with industry experts at your convenience.",
  },
  {
    icon: Video,
    title: "Group Calls",
    description: "Join group sessions and learn alongside peers with similar interests and goals.",
  },
  {
    icon: MessageSquare,
    title: "Direct Messaging",
    description: "Get quick answers and ongoing support through direct messaging with mentors.",
  },
  {
    icon: Star,
    title: "Expert Reviews",
    description: "Read reviews and ratings to find the perfect mentor for your specific needs.",
  },
  {
    icon: Shield,
    title: "Secure Payments",
    description: "Safe and secure payment processing with multiple payment options available.",
  },
  {
    icon: Zap,
    title: "Instant Booking",
    description: "Book sessions instantly or schedule them for later with our flexible booking system.",
  },
]

export function FeaturesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-gray-900 mb-6">
            Everything you need to <span className="text-red-500">grow</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform provides all the tools and features you need to connect with experts and accelerate your
            professional growth.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow"
            >
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                <feature.icon className="w-6 h-6 text-red-500" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
