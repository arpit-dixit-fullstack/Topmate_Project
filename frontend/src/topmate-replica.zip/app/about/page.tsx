"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { motion } from "framer-motion"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              About <span className="text-red-500">Topmate</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We're on a mission to democratize access to expertise and create meaningful connections between knowledge
              seekers and industry leaders.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-16 items-center mb-20">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                Founded in 2021, Topmate started with a simple idea: everyone should have access to expert guidance,
                regardless of their background or location.
              </p>
              <p className="text-gray-600 mb-4">
                We've built a platform that connects ambitious individuals with industry experts, mentors, and thought
                leaders who can provide personalized guidance and insights.
              </p>
              <p className="text-gray-600">
                Today, we're proud to serve thousands of users worldwide, facilitating meaningful conversations that
                drive personal and professional growth.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl p-8 text-white"
            >
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-red-100">
                To create a world where knowledge and expertise are accessible to everyone, fostering growth,
                innovation, and meaningful connections across industries and borders.
              </p>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="grid md:grid-cols-3 gap-8"
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-500">10K+</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Active Users</h3>
              <p className="text-gray-600">Growing community of learners and experts</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-500">500+</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Experts</h3>
              <p className="text-gray-600">Industry leaders across various domains</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-red-500">50+</span>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Countries</h3>
              <p className="text-gray-600">Global reach connecting people worldwide</p>
            </div>
          </motion.div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
